//
//  ItemTableViewCell.swift
//  nkmlovers4
//
//  Created by Kenta Iwamoto on 2017/01/11.
//  Copyright © 2017年 Ibuki KAWAMITSU. All rights reserved.
//

import UIKit

class ItemTableViewCell: UITableViewCell {

    @IBOutlet weak var itemLabel: UILabel!
  
    
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
